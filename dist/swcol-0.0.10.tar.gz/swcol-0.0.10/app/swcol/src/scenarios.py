import pandas as pd
import swcol as sw

def table(model_outputs_path, model_inputs_path):
    new_gen = pd.read_csv(model_outputs_path+'BuildGen.csv')
    new_gen = new_gen[new_gen['GEN_BLD_YRS_2'] >= 2023]
    new_gen = new_gen[new_gen['BuildGen'] > 1]

    gen_info = pd.read_csv(model_inputs_path+'gen_info.csv')
    new_gen = pd.merge(new_gen, gen_info,
                        left_on='GEN_BLD_YRS_1',right_on='GENERATION_PROJECT',how='inner')

    new_gen = new_gen.groupby(['gen_tech','GEN_BLD_YRS_2']).agg({
        'BuildGen' : 'sum'}).reset_index()
    new_gen.rename(columns={'GEN_BLD_YRS_2': 'Year'}, inplace=True)
    new_gen['BuildGen'] = new_gen['BuildGen'].round(2)
    new_gen.rename(columns={'gen_tech': 'Tech'}, inplace=True)

    pivot_table = new_gen.pivot_table(index='Tech',columns='Year',
                                    values='BuildGen',aggfunc='sum').fillna(0)
    pivot_table.loc['Total'] = pivot_table.sum()
    
    return pivot_table

import plotly.express as px
def dispatched_generation(dataframe, x_axis, y_axis, color):
    parse_tech, colors, tech_order, tech_colors = sw.template.get() # Template
    # Change values on gen_tech to match Switch output
    dataframe[color] = dataframe[color].replace(parse_tech)
    dataframe = dataframe.groupby([x_axis, color]).agg({
        y_axis : 'sum'}).reset_index()
    dataframe = dataframe.sort_values(by=[x_axis,y_axis], ascending=[True,False])
    fig = px.bar(
        dataframe, x=x_axis, y=y_axis,
        text=y_axis,
        color=color, title='Generation Dispatch Over Time by Technology',
        labels={y_axis: 'Dispatched Generation (MW)', x_axis: 'Year'},
        color_discrete_map=tech_colors,
        category_orders={"Tech": tech_order},
        height=9*50, width=16*50,
        template='plotly_white',)

    unique_years = dataframe[x_axis].unique()
    # Update layout for better readability if needed
    fig.update_layout(barmode='stack', xaxis_title="Timestamp", xaxis=dict(
        tickvals=unique_years,
        tickangle=-45,
        tickfont=dict(size=10),  # Adjust the font size for better fit
        showgrid=True  # Show grid to help align the labels visually
        ),
        yaxis_title="Dispatched Generation (TWh)")
    fig.update_traces(texttemplate='%{text:.2f}', textposition='inside')
    fig.show()

def annual_emmissions(dataframe, x_axis, y_axis):
    parse_tech, colors, tech_order, tech_colors = sw.template.get() # Template
    fig = px.bar(
        dataframe, x=x_axis, y=y_axis,
        color_discrete_sequence=[colors[0]],
        labels={y_axis: 'Annual Emissions (MtCO2)', x_axis: 'Year'},
        text=y_axis,
        height=9*50, width=16*50,
        template='plotly_white',)
    # Mejorar la visualización
    fig.update_traces(texttemplate='%{text:.2f}', textposition='outside')
    fig.update_layout(xaxis=dict(tickvals=dataframe[x_axis].to_list()))
    fig.show()

from plotly.subplots import make_subplots
def installed_capacity(esc0, escf, dataset):
    parse_tech, colors, tech_order, tech_colors = sw.template.get() # Template
    esc0['Tech'] = esc0['Tech'].replace(parse_tech)
    escf['Tech'] = escf['Tech'].replace(parse_tech)

    # Create individual figures
    fig1 = px.pie(
        esc0, names='Tech', values='BuildGen', color='Tech',
        color_discrete_map=tech_colors, category_orders={"Tech": tech_order})
    fig2 = px.pie(
        escf, names='Tech', values='BuildGen', color='Tech',
        color_discrete_map=tech_colors, category_orders={"Tech": tech_order})
    
    # Create subplots
    fig = make_subplots(rows=1, cols=2,
                       specs=[[{'type':'domain'}, {'type':'domain'}]], 
                       subplot_titles=("2023", "2037"))

    # Add figures to the subplots
    for trace in fig1.data: 
        fig.add_trace(trace, row=1, col=1)
    for trace in fig2.data: 
        fig.add_trace(trace, row=1, col=2)

    # Forzar mostrar todas las leyendas
    fig.update_traces(
        showlegend=True,
        selector=lambda t: True  # Aplica a todos los trazos
    )

    # Move subplot titles to bottom
    for annotation in fig['layout']['annotations']:
        annotation['y'] = -0.05  # Adjust this value as needed
        annotation['yanchor'] = 'top'  # Anchor to top of the text (which is now below the plot)

    # Set fixed figure size and adjust margins if needed
    fig.update_layout(
        height=9*50, width=16*50,
        title_text=f"Installed Capacity ({dataset})",  # Main title
    )
    fig.write_image(f"../images/Installed Capacity ({dataset}).png")
    # Show the figure
    fig.show()